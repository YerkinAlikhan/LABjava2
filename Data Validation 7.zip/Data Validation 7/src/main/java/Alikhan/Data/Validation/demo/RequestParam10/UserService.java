package Alikhan.Data.Validation.demo.RequestParam10;

import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService {
    private List<User> users = new ArrayList<>();

    // Sample data for demonstration
    public UserService() {
        users.add(new User(1L, "Alikhan", "Alikhan@example.com"));
        users.add(new User(2L, "Adelya", "Adelya@example.com"));
        users.add(new User(3L, "Ilzat", "Ilzat@example.com"));
        users.add(new User(4L, "Sabir", "Sabir@example.com"));
    }

    public List<User> getUsers(String name, int page, int size) {
        return users.stream()
                .filter(user -> name == null || user.getName().toLowerCase().contains(name.toLowerCase()))
                .skip(page * size)
                .limit(size)
                .collect(Collectors.toList());
    }
}
