package Alikhan.Data.Validation.demo.ERROR;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class MyController {

    @GetMapping("/throw")
    public String throwException() {
        throw new CustomException("Это сообщение пользовательского исключения");
    }
}
