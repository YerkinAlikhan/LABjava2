package Alikhan.Data.Validation.demo.RequestParam10;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usersten")
public class UserControllerTEN {

    @Autowired
    private UserService userService;

    @GetMapping
    public List<User> getUsers(
            @RequestParam(required = false) String name,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return userService.getUsers(name, page, size);
    }
}
