package Alikhan.Data.Validation.demo.ERROR;

public class CustomException extends RuntimeException {
    public CustomException(String message) {
        super(message);
    }
}
