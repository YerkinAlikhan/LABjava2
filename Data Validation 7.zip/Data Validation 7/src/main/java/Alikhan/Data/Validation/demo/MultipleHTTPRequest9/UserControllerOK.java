package Alikhan.Data.Validation.demo.MultipleHTTPRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/users12")
public class UserControllerOK {
    // In-memory storage for demonstration
    private Map<Integer, String> users = new HashMap<>();
    private int idCounter = 1;

    // Method to handle GET requests to fetch user by ID
    @GetMapping("/{id}")
    public ResponseEntity<Object> getUser(@PathVariable int id) {
        if (users.containsKey(id)) {
            return new ResponseEntity<>(users.get(id), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
        }
    }

    // Method to handle POST requests to create a new user
    @PostMapping
    public ResponseEntity<String> createUser(@RequestBody String userName) {
        users.put(idCounter, userName);
        idCounter++;
        return new ResponseEntity<>("User created successfully", HttpStatus.CREATED);
    }
}

