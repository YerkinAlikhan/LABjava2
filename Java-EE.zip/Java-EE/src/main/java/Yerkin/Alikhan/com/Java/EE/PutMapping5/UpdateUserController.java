package Yerkin.Alikhan.com.Java.EE.PutMapping5;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class UpdateUserController {

    @PutMapping("/user")
    public String updateUser(@RequestParam("id") String id, @RequestBody User user) {
        // Logic to update user information
        return "User with ID " + id + " has been updated";
    }
}

class User {
    private String name;
    private int age;

    // Getters and setters
}
