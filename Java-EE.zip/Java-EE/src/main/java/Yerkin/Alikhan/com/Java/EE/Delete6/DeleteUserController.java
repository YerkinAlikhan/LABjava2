package Yerkin.Alikhan.com.Java.EE.Delete6;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class DeleteUserController {

    @DeleteMapping("/user/{id}")
    public String deleteUser(@PathVariable("id") String id) {
        // Logic to delete user
        return "User with ID " + id + " has been deleted.";
    }
}
