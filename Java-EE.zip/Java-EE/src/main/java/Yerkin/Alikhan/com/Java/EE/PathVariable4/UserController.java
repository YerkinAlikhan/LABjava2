package Yerkin.Alikhan.com.Java.EE.PathVariable4;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class UserController {

    @GetMapping("/user/{id}")
    public String getUserById(@PathVariable("id") String id) {
        return "User with ID " + id + " found";
    }
}