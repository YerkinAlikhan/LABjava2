package Yerkin.Alikhan.com.Java.EE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaEeApplicationTests {

	@Test
	void contextLoads() {
	}

}
